
from flask import Flask
from backtesting import Strategy

# Initialisation de l'application Flask
app = Flask(__name__)
@app.route('/get_stat', methods=['GET','POST'])
def get_stat():

# Configuration de la clé API
 API_KEY = '7D4D2IVSL1NS5WR3'
 BASE_URL = 'https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol=IBM&outputsize=full&apikey={key}&datatype=csv'

# Méthode pour charger les données depuis l'API Alpha Vantage
 def load_data(symbol):
    url = f"{BASE_URL}&symbol={symbol}&outputsize=full&apikey={API_KEY}&datatype=csv"
    df = pd.read_csv(url)
    df = df.rename(columns=str.lower)  # Standardiser les noms de colonnes
    df.dropna(inplace=True)
    return df

# Ajout des indicateurs techniques communs
def add_common_indicators(df):
    df["rsi"] = ta.rsi(df["close"], length=14)
    df["ema_slow"] = ta.ema(df["close"], length=200)
    df["ema_fast"] = ta.ema(df["close"], length=150)
    bbands = ta.bbands(df["close"], length=14, std=2.0)
    df = df.join(bbands)
    df.dropna(inplace=True)
    return df

# Ajout des indicateurs MACD
def add_macd(df):
    macd = ta.macd(df["close"], fast=12, slow=26, signal=9)
    df["MACD"] = macd["MACD_12_26_9"]
    df["MACD_Signal"] = macd["MACDs_12_26_9"]
    df["MACD_Hist"] = macd["MACDh_12_26_9"]
    df.dropna(inplace=True)

# Stratégie 1 : EMA avec Bollinger Bands
class EMAStrategy(Strategy):
    def init(self):
        self.signal = self.I(self.calculate_signal)

    def calculate_signal(self):
        emasignal = [0] * len(self.data)
        for i in range(1, len(self.data)):
            if self.data.ema_slow[i] > self.data.ema_fast[i]:
                emasignal[i] = 2
            elif self.data.ema_slow[i] < self.data.ema_fast[i]:
                emasignal[i] = 1
        return emasignal

    def next(self):
        if len(self.trades) == 0:
            if self.signal[-1] == 2 and self.data.close[-1] <= self.data.bbl_14_2_0[-1]:
                self.buy()
            elif self.signal[-1] == 1 and self.data.close[-1] >= self.data.bbu_14_2_0[-1]:
                self.sell()

# Stratégie 2 : Crossover SMA
class SMACrossoverStrategy(Strategy):
    def init(self):
        self.signal = self.I(self.calculate_signal)

    def calculate_signal(self):
        sma_50 = ta.sma(self.data.close, length=50)
        sma_200 = ta.sma(self.data.close, length=200)
        return (sma_50 > sma_200).astype(int)  # 1 pour achat, 0 pour vente

    def next(self):
        if len(self.trades) == 0:
            if self.signal[-1] == 1:
                self.buy()
            elif self.signal[-1] == 0:
                self.sell()

# Stratégie 3 : Ichimoku
class IchimokuStrategy(Strategy):
    def init(self):
        self.tenkan_sen = self.I(lambda: (self.data.high.rolling(9).max() + self.data.low.rolling(9).min()) / 2)
        self.kijun_sen = self.I(lambda: (self.data.high.rolling(26).max() + self.data.low.rolling(26).min()) / 2)
        self.senkou_span_a = self.I(lambda: (self.tenkan_sen + self.kijun_sen) / 2)
        self.senkou_span_b = self.I(lambda: (self.data.high.rolling(52).max() + self.data.low.rolling(52).min()) / 2)

    def next(self):
        if self.data.close[-1] > self.senkou_span_a[-1] and self.data.close[-1] > self.senkou_span_b[-1]:
            self.buy()
        elif self.data.close[-1] < self.senkou_span_a[-1] and self.data.close[-1] < self.senkou_span_b[-1]:
            self.sell()

# Stratégie 4 : MACD
class MACDStrategy(Strategy):
    def init(self):
        self.macd = self.I(lambda: self.data.MACD)
        self.signal = self.I(lambda: self.data.MACD_Signal)

    def next(self):
        if len(self.trades) > 0:
            if self.trades[-1].is_long and self.macd[-1] < self.signal[-1]:
                self.trades[-1].close()
            elif self.trades[-1].is_short and self.macd[-1] > self.signal[-1]:
                self.trades[-1].close()

        if self.macd[-1] > self.signal[-1] and len(self.trades) == 0:
            self.buy()
        elif self.macd[-1] < self.signal[-1] and len(self.trades) == 0:
            self.sell()

# Route API pour exécuter une stratégie
@app.route("/get_stat", methods=["GET"])
def get_stat():
    symbol = request.args.get("symbol", "IBM")
    cash = float(request.args.get("cash", 10000))
    margin = float(request.args.get("margin", 1/2))
    strat_num = int(request.args.get("stratNum", 1))

    # Charger les données
    df = load_data(symbol)
    df = add_common_indicators(df)

    # Ajouter MACD si nécessaire
    if strat_num == 4:
        add_macd(df)

    # Copier et formater les colonnes pour le backtesting
    df_copy = df.rename(columns={"open": "Open", "high": "High", "low": "Low", "close": "Close", "volume": "Volume"})

    # Choisir la stratégie
    #if strat_num == 1:
    bt = Backtest(df_copy, EMAStrategy, cash=100, margin=1/2, commission=0.0005)
    #elif strat_num == 2:
        #bt = Backtest(df_copy, SMACrossoverStrategy, cash=100, margin=1/2, commission=0.0005)
   # elif strat_num == 3:
       # bt = Backtest(df_copy, IchimokuStrategy, cash=100, margin=1/2, commission=0.0005)
   # elif strat_num == 4:
       # bt = Backtest(df_copy, MACDStrategy, cash=100, margin=1/2, commission=0.0005)
    #else:
        #return jsonify({"error": "Stratégie invalide"}), 400

    # Exécuter la stratégie
    stat = bt.run()

    # Préparer les statistiques à retourner
    stat_dict = {key: stat[key] for key in stat.keys()}
    return jsonify(stat_dict)

if __name__ == "__main__":
    app.run(debug=True)
